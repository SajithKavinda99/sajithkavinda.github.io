
package java_calculator;

public class Java_calculator {
    public static void main(String[] args) {
        
        calculator start = new calculator();
        start.setVisible(true);
    }
    
}
